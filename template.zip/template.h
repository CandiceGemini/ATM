#ifndef TEMPLATE_H_
#define TEMPLATE_H_
#include<iostream>
using namespace std;

template<typename T>
void Max(const T &vec)
{
	auto max = vec[0];
	for (int n = 1; n < vec.size(); n++)
	{
		if (vec[n]>max)
			max = vec[n];
	}
	cout << "the max: " << max << endl;
}

template<typename T>
void Max(const T arr[], int size)
{
	auto max = arr[0];
	for (int n = 1; n < size; n++)
	{
		if (arr[n]>max)
			max = arr[n];
	}
	cout << "the max: " << max << endl;
}
#endif