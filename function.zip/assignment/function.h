#ifndef FUNCTION_H_
#define FUNCTION_H_
#include<iostream>
#include<vector>
#include<string>
#include<array>
using namespace std;
void max(const vector<int> &vec)
{
	int max = vec[0];
	for (int n = 1; n < vec.size(); n++)
	{
		if (max < vec[n])
			max = vec[n];
	}
	cout << "The max number: " << max << endl;
}
void max(const vector<float> &vec)
{
	float max = vec[0];
	for (int n = 1; n < vec.size(); n++)
	{
		if (max < vec[n])
			max = vec[n];
	}
	cout << "The max number: " << max << endl;
}
void max(const vector<string> &vec)
{
	string max = vec[0];
	for (int n = 1; n < vec.size(); n++)
	{
		if (max < vec[n])
			max = vec[n];
	}
	cout << "The max string: " << max << endl;
}

void max(const int arr[], int size)
{
	int max = arr[0];
	for (int n = 1; n < size; n++)
	{
		if (max < arr[n])
		{
			max = arr[n];
		}
	}
	cout << "The max number: " << max << endl;
}
void max(const float arr[], int size)
{
	float max = arr[0];
	for (int n = 1; n < size; n++)
	{
		if (max < arr[n])
		{
			max = arr[n];
		}
	}
	cout << "The max number: " << max << endl;
}
void max(const string arr[], int size)
{
	string max = arr[0];
	for (int n = 1; n < size; n++)
	{
		if (max < arr[n])
		{
			max = arr[n];
		}
	}
	cout << "The max string: " << max << endl;
}



#endif
