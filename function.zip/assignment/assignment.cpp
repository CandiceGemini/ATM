#include<iostream>
#include"function.h"
#include<string>
#include<vector>
using namespace std;
int main()
{
	vector<int> vec1(20);
	vector<float> vec2(20);
	vector<string> vec3(5);

	int arr1[20];
	float arr2[20];
	string arr3[5];
	int size_1 = 20,size_2=20,size_3=5;

	for (int n = 0; n < 20; n++)
	{
		cin >> vec1[n];
	}
	max(vec1);
	
	for (int n = 0; n < 20; n++)
	{
		cin >> vec2[n];
	}
	max(vec2);
	
	for (int n = 0; n < 5; n++)
	{
		cin >> vec3[n];
	}
	max(vec3);
	


	for (int n = 0; n < 20; n++)
	{
		cin >> arr1[n];
	}
	max(arr1, size_1);
	
	for (int n = 0; n < 20; n++)
	{
		cin >> arr2[n];
	}
	max(arr2, size_2);
	
	for (int n = 0; n < 5; n++)
	{
		cin >> arr3[n];
	}
	max(arr3, size_3);
	

	return 0;
}